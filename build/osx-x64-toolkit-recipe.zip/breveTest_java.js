var breve = {
    monkey: "Object",
    name: "String",
    tail: "Boolean"
}

//Default,
//    Boolean,
//    Int,
//    Long,
//    Decimal,
//    String,
//    ByteArray,
//    DateTime